CalendarXP
==========

This repo contains a javascript based calendar (FlatCalendarXP) and date picker (PopCalendarXP). Please visit http://www.calendarxp.net for more detailed introductions and manual.

## Installation

It's as easy as embed an <iframe> tag in page. Detailed tutorials can be found here http://www.calendarxp.net/Tutorials.shtml

## License

CalendarXP is © 2013 [Victor Weng](http://www.github.com/victorwon) and may be freely
distributed under the [MIT license](http://opensource.org/licenses/MIT).

