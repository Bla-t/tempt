<?php
/*
	if (!empty($_SERVER['HTTPS']) && ('on' == $_SERVER['HTTPS'])) {
		$uri = 'https://';
	} else {
		$uri = 'http://';
	}
	$uri .= $_SERVER['HTTP_HOST'];

	session_start();
	$foldernya = '/tabah/asanoer/';
	$uri = $uri.$foldernya;
	session_destroy();
	header('location:'.$uri.'index.php');
	exit();
*/
?>